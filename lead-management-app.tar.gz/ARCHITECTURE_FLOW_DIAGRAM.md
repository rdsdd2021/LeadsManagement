# 🏗️ Lead Management System - Architecture & Data Flow

## Table of Contents
1. [System Overview](#system-overview)
2. [Filter Flow](#filter-flow)
3. [Leads Data Flow](#leads-data-flow)
4. [Unique Values Flow](#unique-values-flow)
5. [Filter Counts Flow](#filter-counts-flow)
6. [Bulk Operations Flow](#bulk-operations-flow)
7. [CSV Import Flow](#csv-import-flow)
8. [Authentication Flow](#authentication-flow)
9. [Realtime Updates Flow](#realtime-updates-flow)
10. [Complete Interaction Map](#complete-interaction-map)

---

## 1. System Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                         FRONTEND (Next.js)                       │
├─────────────────────────────────────────────────────────────────┤
│                                                                   │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐          │
│  │   Pages      │  │  Components  │  │    Hooks     │          │
│  │              │  │              │  │              │          │
│  │ • Home       │  │ • FilterPanel│  │ • useLeads   │          │
│  │ • Buckets    │  │ • LeadTable  │  │ • useFilters │          │
│  │ • Users      │  │ • BulkAssign │  │ • useBulk*   │          │
│  └──────┬───────┘  └──────┬───────┘  └──────┬───────┘          │
│         │                 │                  │                   │
│         └─────────────────┴──────────────────┘                   │
│                           │                                       │
│                  ┌────────▼────────┐                             │
│                  │  Zustand Store  │                             │
│                  │  (filterStore)  │                             │
│                  └────────┬────────┘                             │
│                           │                                       │
│         ┌─────────────────┼─────────────────┐                   │
│         │                 │                 │                   │
│    ┌────▼────┐      ┌────▼────┐      ┌────▼────┐              │
│    │ API     │      │ Supabase│      │ Edge    │              │
│    │ Routes  │      │ Client  │      │ Functions│              │
│    └────┬────┘      └────┬────┘      └────┬────┘              │
│         │                 │                 │                   │
└─────────┼─────────────────┼─────────────────┼───────────────────┘
          │                 │                 │
          └─────────────────┴─────────────────┘
                            │
┌───────────────────────────▼───────────────────────────┐
│                    SUPABASE BACKEND                    │
├────────────────────────────────────────────────────────┤
│                                                         │
│  ┌──────────────┐  ┌──────────────┐  ┌─────────────┐ │
│  │  PostgreSQL  │  │  Functions   │  │   Storage   │ │
│  │              │  │              │  │             │ │
│  │ • users      │  │ • get_filter │  │ • csv-      │ │
│  │ • leads      │  │   _counts()  │  │   imports   │ │
│  │ • buckets    │  │ • get_unique │  │             │ │
│  │ • custom_    │  │   _values()  │  │             │ │
│  │   fields     │  │ • is_admin() │  │             │ │
│  │ • import_    │  │ • is_admin_  │  │             │ │
│  │   jobs       │  │   or_mgr()   │  │             │ │
│  └──────────────┘  └──────────────┘  └─────────────┘ │
│                                                         │
│  ┌──────────────────────────────────────────────────┐ │
│  │              RLS Policies (Security)              │ │
│  │  • Admin/Manager: See all leads                   │ │
│  │  • Sales Rep: See only assigned leads             │ │
│  │  • Viewer: See only assigned leads                │ │
│  └──────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────┘
```


---

## 2. Filter Flow - How Filters Work

```
USER INTERACTION
       │
       ▼
┌──────────────────────────────────────────────────────────────┐
│ 1. USER TYPES/SELECTS FILTER                                 │
│    Example: User selects "Male" in Gender filter             │
└──────────────────┬───────────────────────────────────────────┘
                   │
                   ▼
┌──────────────────────────────────────────────────────────────┐
│ 2. COMPONENT CALLS STORE ACTION                              │
│    FilterPanel.tsx                                            │
│    ├─ onChange={(value) => setGender(value)}                 │
│    └─ Immediate UI update (checkbox checked)                 │
└──────────────────┬───────────────────────────────────────────┘
                   │
                   ▼
┌──────────────────────────────────────────────────────────────┐
│ 3. ZUSTAND STORE UPDATES (filterStore.ts)                    │
│    ┌──────────────────────────────────────────────────────┐ │
│    │ setGender: (gender) => {                             │ │
│    │   set({ gender, page: 0 })  ← Immediate state       │ │
│    │   clearTimeout(debounceTimer)                        │ │
│    │   debounceTimer = setTimeout(() => {                 │ │
│    │     applyDebouncedFilters()  ← After 800ms          │ │
│    │   }, 800)                                            │ │
│    │ }                                                     │ │
│    └──────────────────────────────────────────────────────┘ │
│                                                               │
│    State Structure:                                           │
│    ├─ gender: ['Male']           ← Immediate (UI)           │
│    └─ debouncedGender: ['Male']  ← After 800ms (API)        │
└──────────────────┬───────────────────────────────────────────┘
                   │
                   ▼ (After 800ms debounce)
┌──────────────────────────────────────────────────────────────┐
│ 4. REACT QUERY DETECTS CHANGE                                │
│    useLeads() hook watches debouncedGender                    │
│    ├─ queryKey changes                                        │
│    └─ Triggers refetch                                        │
└──────────────────┬───────────────────────────────────────────┘
                   │
                   ▼
┌──────────────────────────────────────────────────────────────┐
│ 5. THREE PARALLEL API CALLS                                  │
│    ┌────────────────┐  ┌────────────────┐  ┌──────────────┐│
│    │ GET LEADS      │  │ GET FILTER     │  │ GET UNIQUE   ││
│    │ /api/leads     │  │ COUNTS         │  │ VALUES       ││
│    │                │  │ /api/filter-   │  │ /api/unique- ││
│    │ Returns:       │  │ counts         │  │ values       ││
│    │ • 25 leads     │  │                │  │              ││
│    │ • Total count  │  │ Returns:       │  │ Returns:     ││
│    │                │  │ • School: {    │  │ • All schools││
│    │                │  │   "ABC": 50    │  │ • All        ││
│    │                │  │   "XYZ": 30    │  │   districts  ││
│    │                │  │ }              │  │ • All genders││
│    │                │  │ • District: {} │  │ • All streams││
│    │                │  │ • Gender: {}   │  │              ││
│    │                │  │ • Stream: {}   │  │              ││
│    └────────┬───────┘  └────────┬───────┘  └──────┬───────┘│
│             │                   │                  │         │
└─────────────┼───────────────────┼──────────────────┼─────────┘
              │                   │                  │
              ▼                   ▼                  ▼
┌──────────────────────────────────────────────────────────────┐
│ 6. COMPONENTS RE-RENDER WITH NEW DATA                        │
│    ┌────────────────┐  ┌────────────────┐  ┌──────────────┐│
│    │ LeadTable      │  │ FilterPanel    │  │ FilterPanel  ││
│    │ Shows filtered │  │ Shows counts   │  │ Shows        ││
│    │ leads          │  │ next to each   │  │ dropdown     ││
│    │                │  │ filter option  │  │ options      ││
│    └────────────────┘  └────────────────┘  └──────────────┘│
└──────────────────────────────────────────────────────────────┘
```

### Why Debouncing?

```
WITHOUT DEBOUNCE:
User types "John" → 4 API calls (J, Jo, Joh, John)
❌ Wastes resources
❌ Slower performance
❌ Database overload

WITH DEBOUNCE (800ms):
User types "John" → Wait 800ms → 1 API call (John)
✅ Efficient
✅ Fast
✅ Database friendly
```


---

## 3. Leads Data Flow - How Leads are Fetched

```
┌─────────────────────────────────────────────────────────────────┐
│ SCENARIO: User wants to see leads filtered by "Male" gender     │
└─────────────────────────────────────────────────────────────────┘

STEP 1: HOOK INITIATES REQUEST
┌──────────────────────────────────────────────────────────────┐
│ useLeads.ts                                                   │
│ ┌──────────────────────────────────────────────────────────┐ │
│ │ const { debouncedGender } = useFilterStore()             │ │
│ │                                                           │ │
│ │ useQuery({                                               │ │
│ │   queryKey: ['leads', { gender: ['Male'], ... }]        │ │
│ │   queryFn: async () => {                                 │ │
│ │     const response = await fetch('/api/leads', {         │ │
│ │       method: 'POST',                                    │ │
│ │       body: JSON.stringify({ gender: ['Male'] })         │ │
│ │     })                                                    │ │
│ │   }                                                       │ │
│ │ })                                                        │ │
│ └──────────────────────────────────────────────────────────┘ │
└──────────────────┬───────────────────────────────────────────┘
                   │
                   ▼
STEP 2: API ROUTE PROCESSES REQUEST
┌──────────────────────────────────────────────────────────────┐
│ app/api/leads/route.ts                                        │
│ ┌──────────────────────────────────────────────────────────┐ │
│ │ export async function POST(request) {                    │ │
│ │   const { gender, school, district, ... } = await       │ │
│ │     request.json()                                       │ │
│ │                                                           │ │
│ │   // Build Supabase query                               │ │
│ │   let query = supabaseServer                            │ │
│ │     .from('leads')                                       │ │
│ │     .select('*, assigned_user:users!assigned_to(...)')  │ │
│ │                                                           │ │
│ │   // Apply filters                                       │ │
│ │   if (gender.length > 0) {                              │ │
│ │     query = query.in('gender', gender)                  │ │
│ │   }                                                       │ │
│ │                                                           │ │
│ │   // Execute with pagination                            │ │
│ │   const { data, count } = await query                   │ │
│ │     .range(start, end)                                   │ │
│ │                                                           │ │
│ │   return NextResponse.json({ data, count })             │ │
│ │ }                                                         │ │
│ └──────────────────────────────────────────────────────────┘ │
└──────────────────┬───────────────────────────────────────────┘
                   │
                   ▼
STEP 3: SUPABASE EXECUTES QUERY
┌──────────────────────────────────────────────────────────────┐
│ PostgreSQL Database                                           │
│ ┌──────────────────────────────────────────────────────────┐ │
│ │ Generated SQL:                                           │ │
│ │                                                           │ │
│ │ SELECT                                                    │ │
│ │   leads.*,                                               │ │
│ │   users.id, users.email, users.name                      │ │
│ │ FROM leads                                               │ │
│ │ LEFT JOIN users ON leads.assigned_to = users.id         │ │
│ │ WHERE                                                     │ │
│ │   gender = ANY(ARRAY['Male'])                           │ │
│ │   AND (                                                   │ │
│ │     is_admin_or_manager()                               │ │
│ │     OR assigned_to = auth.uid()                         │ │
│ │   )  ← RLS Policy                                       │ │
│ │ ORDER BY created_at DESC                                 │ │
│ │ LIMIT 25 OFFSET 0                                        │ │
│ │                                                           │ │
│ │ Uses Indexes:                                            │ │
│ │ • idx_leads_gender (fast gender filter)                 │ │
│ │ • idx_leads_created_at (fast sorting)                   │ │
│ │ • idx_users_role (fast RLS check)                       │ │
│ └──────────────────────────────────────────────────────────┘ │
│                                                               │
│ Performance: ~50-200ms                                        │
└──────────────────┬───────────────────────────────────────────┘
                   │
                   ▼
STEP 4: DATA FLOWS BACK
┌──────────────────────────────────────────────────────────────┐
│ Response Structure:                                           │
│ {                                                             │
│   data: [                                                     │
│     {                                                         │
│       id: "uuid-1",                                          │
│       name: "John Doe",                                      │
│       phone: "1234567890",                                   │
│       school: "ABC School",                                  │
│       gender: "Male",                                        │
│       assigned_user: {                                       │
│         id: "user-uuid",                                     │
│         email: "sales@example.com",                          │
│         name: "Sales Rep"                                    │
│       },                                                      │
│       custom_fields: { ... }                                 │
│     },                                                        │
│     // ... 24 more leads                                     │
│   ],                                                          │
│   count: 2500  ← Total matching leads                        │
│ }                                                             │
└──────────────────┬───────────────────────────────────────────┘
                   │
                   ▼
STEP 5: REACT QUERY CACHES & PROVIDES DATA
┌──────────────────────────────────────────────────────────────┐
│ React Query Cache                                             │
│ ┌──────────────────────────────────────────────────────────┐ │
│ │ Key: ['leads', { gender: ['Male'], page: 0 }]           │ │
│ │ Data: { data: [...], count: 2500 }                      │ │
│ │ Cached for: 30 seconds                                   │ │
│ │ Status: 'success'                                        │ │
│ └──────────────────────────────────────────────────────────┘ │
└──────────────────┬───────────────────────────────────────────┘
                   │
                   ▼
STEP 6: COMPONENT RENDERS
┌──────────────────────────────────────────────────────────────┐
│ LeadTable Component                                           │
│ ┌──────────────────────────────────────────────────────────┐ │
│ │ const { data, isLoading } = useLeads()                   │ │
│ │                                                           │ │
│ │ if (isLoading) return <Spinner />                        │ │
│ │                                                           │ │
│ │ return (                                                  │ │
│ │   <table>                                                 │ │
│ │     {data.data.map(lead => (                            │ │
│ │       <tr key={lead.id}>                                 │ │
│ │         <td>{lead.name}</td>                            │ │
│ │         <td>{lead.phone}</td>                           │ │
│ │         <td>{lead.school}</td>                          │ │
│ │         <td>{lead.gender}</td>                          │ │
│ │       </tr>                                              │ │
│ │     ))}                                                   │ │
│ │   </table>                                                │ │
│ │ )                                                         │ │
│ └──────────────────────────────────────────────────────────┘ │
└──────────────────────────────────────────────────────────────┘
```


---

## 4. Unique Values Flow - Dropdown Options

```
┌─────────────────────────────────────────────────────────────────┐
│ SCENARIO: FilterPanel needs to show all available schools       │
└─────────────────────────────────────────────────────────────────┘

STEP 1: COMPONENT MOUNTS
┌──────────────────────────────────────────────────────────────┐
│ FilterPanel.tsx                                               │
│ ┌──────────────────────────────────────────────────────────┐ │
│ │ const { data: uniqueValues } = useUniqueValues()         │ │
│ │                                                           │ │
│ │ <Select>                                                  │ │
│ │   {uniqueValues?.school.map(school => (                 │ │
│ │     <Option value={school}>{school}</Option>            │ │
│ │   ))}                                                     │ │
│ │ </Select>                                                 │ │
│ └──────────────────────────────────────────────────────────┘ │
└──────────────────┬───────────────────────────────────────────┘
                   │
                   ▼
STEP 2: HOOK FETCHES DATA
┌──────────────────────────────────────────────────────────────┐
│ useUniqueValues.ts                                            │
│ ┌──────────────────────────────────────────────────────────┐ │
│ │ useQuery({                                               │ │
│ │   queryKey: ['unique-values'],                          │ │
│ │   queryFn: async () => {                                 │ │
│ │     const response = await fetch('/api/unique-values')   │ │
│ │     return response.json()                               │ │
│ │   },                                                      │ │
│ │   staleTime: 60000  ← Cache for 60 seconds              │ │
│ │ })                                                        │ │
│ └──────────────────────────────────────────────────────────┘ │
└──────────────────┬───────────────────────────────────────────┘
                   │
                   ▼
STEP 3: API ROUTE CALLS DATABASE FUNCTION
┌──────────────────────────────────────────────────────────────┐
│ app/api/unique-values/route.ts                                │
│ ┌──────────────────────────────────────────────────────────┐ │
│ │ export async function GET() {                            │ │
│ │   // Call database function (server-side aggregation)    │ │
│ │   const { data, error } = await supabaseServer          │ │
│ │     .rpc('get_unique_values')                           │ │
│ │                                                           │ │
│ │   return NextResponse.json(data)                         │ │
│ │ }                                                         │ │
│ └──────────────────────────────────────────────────────────┘ │
└──────────────────┬───────────────────────────────────────────┘
                   │
                   ▼
STEP 4: DATABASE FUNCTION EXECUTES
┌──────────────────────────────────────────────────────────────┐
│ PostgreSQL Function: get_unique_values()                      │
│ ┌──────────────────────────────────────────────────────────┐ │
│ │ CREATE FUNCTION get_unique_values()                      │ │
│ │ RETURNS jsonb AS $$                                      │ │
│ │ DECLARE                                                   │ │
│ │   v_schools jsonb;                                       │ │
│ │   v_districts jsonb;                                     │ │
│ │   v_genders jsonb;                                       │ │
│ │   v_streams jsonb;                                       │ │
│ │ BEGIN                                                     │ │
│ │   -- Get unique schools                                  │ │
│ │   SELECT jsonb_agg(DISTINCT school ORDER BY school)     │ │
│ │   INTO v_schools                                         │ │
│ │   FROM leads                                             │ │
│ │   WHERE school IS NOT NULL AND school != '';            │ │
│ │                                                           │ │
│ │   -- Same for district, gender, stream...               │ │
│ │                                                           │ │
│ │   RETURN jsonb_build_object(                            │ │
│ │     'school', v_schools,                                 │ │
│ │     'district', v_districts,                             │ │
│ │     'gender', v_genders,                                 │ │
│ │     'stream', v_streams                                  │ │
│ │   );                                                      │ │
│ │ END;                                                      │ │
│ │ $$ LANGUAGE plpgsql SECURITY INVOKER;                   │ │
│ └──────────────────────────────────────────────────────────┘ │
│                                                               │
│ Why SECURITY INVOKER?                                         │
│ • Respects RLS policies                                      │
│ • Admin sees all schools                                     │
│ • Sales rep sees only schools from assigned leads            │
│                                                               │
│ Performance: ~100-400ms (depends on data size)               │
└──────────────────┬───────────────────────────────────────────┘
                   │
                   ▼
STEP 5: RESPONSE STRUCTURE
┌──────────────────────────────────────────────────────────────┐
│ {                                                             │
│   school: [                                                   │
│     "ABC High School",                                       │
│     "XYZ Academy",                                           │
│     "Springfield School",                                    │
│     // ... 500 more schools                                  │
│   ],                                                          │
│   district: [                                                 │
│     "Central District",                                      │
│     "North District",                                        │
│     // ... 50 districts                                      │
│   ],                                                          │
│   gender: ["Male", "Female", "Other"],                       │
│   stream: ["Science", "Commerce", "Arts"]                    │
│ }                                                             │
└──────────────────┬───────────────────────────────────────────┘
                   │
                   ▼
STEP 6: DROPDOWN RENDERS
┌──────────────────────────────────────────────────────────────┐
│ FilterPanel UI                                                │
│ ┌──────────────────────────────────────────────────────────┐ │
│ │ School Filter:                                           │ │
│ │ ┌────────────────────────────────────────────────────┐  │ │
│ │ │ [Select School...]                            ▼    │  │ │
│ │ └────────────────────────────────────────────────────┘  │ │
│ │   ↓ (User clicks)                                       │ │
│ │ ┌────────────────────────────────────────────────────┐  │ │
│ │ │ ☐ ABC High School                                  │  │ │
│ │ │ ☐ XYZ Academy                                      │  │ │
│ │ │ ☐ Springfield School                               │  │ │
│ │ │ ... (500 more options)                             │  │ │
│ │ └────────────────────────────────────────────────────┘  │ │
│ └──────────────────────────────────────────────────────────┘ │
└──────────────────────────────────────────────────────────────┘
```


---

## 5. Filter Counts Flow - Faceted Search

```
┌─────────────────────────────────────────────────────────────────┐
│ SCENARIO: Show how many leads match each filter option          │
│ Example: "Male (1,200)" "Female (1,300)"                        │
└─────────────────────────────────────────────────────────────────┘

STEP 1: HOOK WATCHES FOR FILTER CHANGES
┌──────────────────────────────────────────────────────────────┐
│ useFilterValueCounts.ts                                       │
│ ┌──────────────────────────────────────────────────────────┐ │
│ │ const { debouncedSchool, debouncedDistrict, ... } =     │ │
│ │   useFilterStore()                                       │ │
│ │                                                           │ │
│ │ useQuery({                                               │ │
│ │   queryKey: ['filter-counts', {                         │ │
│ │     school, district, gender, stream                    │ │
│ │   }],                                                     │ │
│ │   queryFn: async () => {                                 │ │
│ │     const response = await fetch('/api/filter-counts', {│ │
│ │       method: 'POST',                                    │ │
│ │       body: JSON.stringify({ school, district, ... })   │ │
│ │     })                                                    │ │
│ │   }                                                       │ │
│ │ })                                                        │ │
│ └──────────────────────────────────────────────────────────┘ │
└──────────────────┬───────────────────────────────────────────┘
                   │
                   ▼
STEP 2: API ROUTE CALLS DATABASE FUNCTION
┌──────────────────────────────────────────────────────────────┐
│ app/api/filter-counts/route.ts                                │
│ ┌──────────────────────────────────────────────────────────┐ │
│ │ export async function POST(request) {                    │ │
│ │   const filters = await request.json()                   │ │
│ │                                                           │ │
│ │   const { data } = await supabaseServer.rpc(            │ │
│ │     'get_filter_counts',                                │ │
│ │     {                                                     │ │
│ │       p_school: filters.school,                         │ │
│ │       p_district: filters.district,                     │ │
│ │       p_gender: filters.gender,                         │ │
│ │       p_stream: filters.stream,                         │ │
│ │       p_search_query: filters.searchQuery,              │ │
│ │       p_date_from: filters.dateRange.from,              │ │
│ │       p_date_to: filters.dateRange.to                   │ │
│ │     }                                                     │ │
│ │   )                                                       │ │
│ │                                                           │ │
│ │   return NextResponse.json(data)                         │ │
│ │ }                                                         │ │
│ └──────────────────────────────────────────────────────────┘ │
└──────────────────┬───────────────────────────────────────────┘
                   │
                   ▼
STEP 3: DATABASE FUNCTION - FACETED SEARCH LOGIC
┌──────────────────────────────────────────────────────────────┐
│ PostgreSQL Function: get_filter_counts()                      │
│ ┌──────────────────────────────────────────────────────────┐ │
│ │ Key Concept: EXCLUDE the field being counted            │ │
│ │                                                           │ │
│ │ Example: Counting GENDER options                         │ │
│ │ ┌──────────────────────────────────────────────────────┐│ │
│ │ │ SELECT gender, COUNT(*) as count                     ││ │
│ │ │ FROM leads                                            ││ │
│ │ │ WHERE                                                 ││ │
│ │ │   -- Apply OTHER filters (NOT gender)                ││ │
│ │ │   school = ANY(p_school)      ← Applied             ││ │
│ │ │   AND district = ANY(p_district) ← Applied          ││ │
│ │ │   AND stream = ANY(p_stream)  ← Applied             ││ │
│ │ │   -- DON'T filter by gender! We're counting it      ││ │
│ │ │ GROUP BY gender                                       ││ │
│ │ └──────────────────────────────────────────────────────┘│ │
│ │                                                           │ │
│ │ Why exclude the field being counted?                     │ │
│ │ • Shows "what if" scenarios                             │ │
│ │ • User can see impact of changing filter                │ │
│ │ • Enables faceted search UX                             │ │
│ │                                                           │ │
│ │ Optimization:                                            │ │
│ │ • Uses indexes (idx_leads_gender, etc.)                 │ │
│ │ • Filters schools with <20 leads                        │ │
│ │ • Runs 5 queries in parallel (school, district, etc.)   │ │
│ └──────────────────────────────────────────────────────────┘ │
│                                                               │
│ Performance: ~200-800ms (depends on filters)                 │
└──────────────────┬───────────────────────────────────────────┘
                   │
                   ▼
STEP 4: RESPONSE STRUCTURE
┌──────────────────────────────────────────────────────────────┐
│ {                                                             │
│   school: {                                                   │
│     "ABC High School": 450,                                  │
│     "XYZ Academy": 320,                                      │
│     "Springfield School": 280,                               │
│     // Only schools with 20+ leads                           │
│   },                                                          │
│   district: {                                                 │
│     "Central District": 800,                                 │
│     "North District": 600,                                   │
│     "South District": 400                                    │
│   },                                                          │
│   gender: {                                                   │
│     "Male": 1200,                                            │
│     "Female": 1300                                           │
│   },                                                          │
│   stream: {                                                   │
│     "Science": 900,                                          │
│     "Commerce": 800,                                         │
│     "Arts": 800                                              │
│   },                                                          │
│   customFields: {                                             │
│     "grade": {                                               │
│       "10th": 500,                                           │
│       "11th": 600,                                           │
│       "12th": 1400                                           │
│     }                                                         │
│   }                                                           │
│ }                                                             │
└──────────────────┬───────────────────────────────────────────┘
                   │
                   ▼
STEP 5: UI RENDERS WITH COUNTS
┌──────────────────────────────────────────────────────────────┐
│ FilterPanel UI                                                │
│ ┌──────────────────────────────────────────────────────────┐ │
│ │ Gender Filter:                                           │ │
│ │ ┌────────────────────────────────────────────────────┐  │ │
│ │ │ ☐ Male (1,200)                                     │  │ │
│ │ │ ☐ Female (1,300)                                   │  │ │
│ │ └────────────────────────────────────────────────────┘  │ │
│ │                                                           │ │
│ │ Stream Filter:                                           │ │
│ │ ┌────────────────────────────────────────────────────┐  │ │
│ │ │ ☐ Science (900)                                    │  │ │
│ │ │ ☐ Commerce (800)                                   │  │ │
│ │ │ ☐ Arts (800)                                       │  │ │
│ │ └────────────────────────────────────────────────────┘  │ │
│ │                                                           │ │
│ │ User can see:                                            │ │
│ │ • How many leads match each option                       │ │
│ │ • Impact of selecting/deselecting filters                │ │
│ │ • Which options have no results (count = 0)              │ │
│ └──────────────────────────────────────────────────────────┘ │
└──────────────────────────────────────────────────────────────┘
```


---

## 6. Bulk Operations Flow

### 6A. Bulk Assign Flow

```
USER ACTION: Assign 1000 leads to 3 sales reps
┌──────────────────────────────────────────────────────────────┐
│ 1. USER OPENS BULK ASSIGN DIALOG                             │
│    • Selects users: [User A: 400, User B: 300, User C: 300] │
│    • Clicks "Assign"                                          │
└──────────────────┬───────────────────────────────────────────┘
                   ▼
┌──────────────────────────────────────────────────────────────┐
│ 2. useBulkAssign() HOOK                                       │
│    ├─ Gets current filters from filterStore                   │
│    ├─ Calls Edge Function (preferred) OR client-side         │
│    └─ Shows progress dialog                                   │
└──────────────────┬───────────────────────────────────────────┘
                   ▼
┌──────────────────────────────────────────────────────────────┐
│ 3. EDGE FUNCTION: bulk-assign-leads                           │
│    supabase/functions/bulk-assign-leads/index.ts              │
│    ┌──────────────────────────────────────────────────────┐  │
│    │ 1. Authenticate user (check if admin/manager)        │  │
│    │ 2. Build query with filters                          │  │
│    │ 3. Fetch lead IDs (in batches of 1000)              │  │
│    │ 4. Distribute leads to users:                        │  │
│    │    • User A gets leads 0-399                         │  │
│    │    • User B gets leads 400-699                       │  │
│    │    • User C gets leads 700-999                       │  │
│    │ 5. Update in batches (100 at a time)                │  │
│    │ 6. Return total assigned count                       │  │
│    └──────────────────────────────────────────────────────┘  │
└──────────────────┬───────────────────────────────────────────┘
                   ▼
┌──────────────────────────────────────────────────────────────┐
│ 4. DATABASE UPDATES                                           │
│    UPDATE leads                                               │
│    SET                                                        │
│      assigned_to = 'user-a-uuid',                            │
│      assignment_date = NOW(),                                │
│      updated_at = NOW()                                      │
│    WHERE id IN (lead-1, lead-2, ..., lead-400)              │
│                                                               │
│    (Repeat for User B and User C)                            │
└──────────────────┬───────────────────────────────────────────┘
                   ▼
┌──────────────────────────────────────────────────────────────┐
│ 5. REALTIME UPDATES                                           │
│    • Supabase broadcasts changes                             │
│    • All connected clients receive updates                   │
│    • React Query invalidates cache                           │
│    • UI refreshes automatically                              │
└──────────────────────────────────────────────────────────────┘
```

### 6B. Bulk Delete Flow

```
USER ACTION: Delete 500 filtered leads
┌──────────────────────────────────────────────────────────────┐
│ 1. USER CLICKS "DELETE FILTERED LEADS"                       │
│    • Confirms deletion                                        │
│    • Shows progress                                           │
└──────────────────┬───────────────────────────────────────────┘
                   ▼
┌──────────────────────────────────────────────────────────────┐
│ 2. useBulkDelete() HOOK                                       │
│    ├─ Gets current filters                                    │
│    ├─ Calls Edge Function                                     │
│    └─ Tracks progress                                         │
└──────────────────┬───────────────────────────────────────────┘
                   ▼
┌──────────────────────────────────────────────────────────────┐
│ 3. EDGE FUNCTION: bulk-delete-leads                           │
│    ┌──────────────────────────────────────────────────────┐  │
│    │ 1. Authenticate (admin/manager only)                 │  │
│    │ 2. Build query with filters                          │  │
│    │ 3. Fetch lead IDs to delete                          │  │
│    │ 4. Delete in batches (100 at a time)                │  │
│    │ 5. Return deleted count                              │  │
│    └──────────────────────────────────────────────────────┘  │
└──────────────────┬───────────────────────────────────────────┘
                   ▼
┌──────────────────────────────────────────────────────────────┐
│ 4. DATABASE DELETES                                           │
│    DELETE FROM leads                                          │
│    WHERE id IN (lead-1, lead-2, ..., lead-100)              │
│                                                               │
│    (Repeat for remaining batches)                            │
└──────────────────┬───────────────────────────────────────────┘
                   ▼
┌──────────────────────────────────────────────────────────────┐
│ 5. CACHE INVALIDATION                                         │
│    • Invalidate leads query                                   │
│    • Invalidate filter counts                                 │
│    • Invalidate unique values                                 │
│    • UI refreshes with updated data                           │
└──────────────────────────────────────────────────────────────┘
```


---

## 7. CSV Import Flow

```
USER ACTION: Import 5000 leads from CSV file
┌──────────────────────────────────────────────────────────────┐
│ STEP 1: SELECT BUCKET                                         │
│ ┌──────────────────────────────────────────────────────────┐ │
│ │ User selects: "Seminar Leads" bucket                     │ │
│ │ • Loads custom fields for this bucket                    │ │
│ │ • Shows sample CSV download                              │ │
│ └──────────────────────────────────────────────────────────┘ │
└──────────────────┬───────────────────────────────────────────┘
                   ▼
┌──────────────────────────────────────────────────────────────┐
│ STEP 2: UPLOAD & PARSE CSV                                    │
│ CSVUpload.tsx                                                 │
│ ┌──────────────────────────────────────────────────────────┐ │
│ │ 1. User drops/selects CSV file                           │ │
│ │ 2. Parse CSV (handle quoted values, commas)             │ │
│ │ 3. Extract headers: [Name, Phone, School, Grade, ...]   │ │
│ │ 4. Show preview (first 5 rows)                           │ │
│ │ 5. Auto-map columns to fields                            │ │
│ └──────────────────────────────────────────────────────────┘ │
└──────────────────┬───────────────────────────────────────────┘
                   ▼
┌──────────────────────────────────────────────────────────────┐
│ STEP 3: COLUMN MAPPING                                        │
│ ┌──────────────────────────────────────────────────────────┐ │
│ │ CSV Column          →  Lead Field                        │ │
│ │ ─────────────────────────────────────────────────────── │ │
│ │ "Student Name"      →  Name *                            │ │
│ │ "Contact Number"    →  Phone Number *                    │ │
│ │ "School Name"       →  School *                          │ │
│ │ "Area"              →  District *                        │ │
│ │ "Gender"            →  Gender *                          │ │
│ │ "Course"            →  Stream *                          │ │
│ │ "Grade Level"       →  Grade (custom field)             │ │
│ │ "Parent Phone"      →  Parent Contact (custom field)    │ │
│ │                                                           │ │
│ │ * = Required fields                                      │ │
│ │ User can adjust mappings or skip columns                 │ │
│ └──────────────────────────────────────────────────────────┘ │
└──────────────────┬───────────────────────────────────────────┘
                   ▼
┌──────────────────────────────────────────────────────────────┐
│ STEP 4: UPLOAD TO STORAGE                                     │
│ ┌──────────────────────────────────────────────────────────┐ │
│ │ const filePath = `${userId}/${timestamp}_leads.csv`     │ │
│ │                                                           │ │
│ │ await supabase.storage                                   │ │
│ │   .from('csv-imports')                                   │ │
│ │   .upload(filePath, file)                               │ │
│ │                                                           │ │
│ │ Storage Structure:                                       │ │
│ │ csv-imports/                                             │ │
│ │   └─ user-uuid-123/                                      │ │
│ │       └─ 1699123456789_leads.csv                        │ │
│ └──────────────────────────────────────────────────────────┘ │
└──────────────────┬───────────────────────────────────────────┘
                   ▼
┌──────────────────────────────────────────────────────────────┐
│ STEP 5: CREATE IMPORT JOB                                     │
│ ┌──────────────────────────────────────────────────────────┐ │
│ │ INSERT INTO import_jobs (                                │ │
│ │   user_id,                                               │ │
│ │   bucket_id,                                             │ │
│ │   file_path,                                             │ │
│ │   file_name,                                             │ │
│ │   status                                                 │ │
│ │ ) VALUES (                                               │ │
│ │   'user-uuid',                                           │ │
│ │   'bucket-uuid',                                         │ │
│ │   'user-uuid/1699123456789_leads.csv',                  │ │
│ │   'leads.csv',                                           │ │
│ │   'pending'                                              │ │
│ │ )                                                         │ │
│ └──────────────────────────────────────────────────────────┘ │
└──────────────────┬───────────────────────────────────────────┘
                   ▼
┌──────────────────────────────────────────────────────────────┐
│ STEP 6: TRIGGER EDGE FUNCTION                                 │
│ supabase/functions/import-csv-leads/index.ts                  │
│ ┌──────────────────────────────────────────────────────────┐ │
│ │ 1. Update job status to 'processing'                     │ │
│ │ 2. Download CSV from storage                             │ │
│ │ 3. Parse CSV (handle quotes, commas)                     │ │
│ │ 4. Get custom fields for bucket                          │ │
│ │ 5. Transform rows using column mappings:                 │ │
│ │    {                                                      │ │
│ │      name: row["Student Name"],                          │ │
│ │      phone: row["Contact Number"],                       │ │
│ │      school: row["School Name"],                         │ │
│ │      custom_fields: {                                    │ │
│ │        grade: row["Grade Level"],                        │ │
│ │        parent_contact: row["Parent Phone"]               │ │
│ │      }                                                    │ │
│ │    }                                                      │ │
│ │ 6. Insert in batches (100 at a time)                    │ │
│ │ 7. Update progress after each batch                      │ │
│ │ 8. Handle errors (log failed rows)                       │ │
│ │ 9. Mark job as 'completed'                              │ │
│ │ 10. Delete CSV file from storage                         │ │
│ └──────────────────────────────────────────────────────────┘ │
└──────────────────┬───────────────────────────────────────────┘
                   ▼
┌──────────────────────────────────────────────────────────────┐
│ STEP 7: REALTIME PROGRESS UPDATES                             │
│ ┌──────────────────────────────────────────────────────────┐ │
│ │ Frontend subscribes to import_jobs table:                │ │
│ │                                                           │ │
│ │ supabase                                                 │ │
│ │   .channel(`import-job-${jobId}`)                       │ │
│ │   .on('postgres_changes', {                             │ │
│ │     event: 'UPDATE',                                     │ │
│ │     table: 'import_jobs',                               │ │
│ │     filter: `id=eq.${jobId}`                            │ │
│ │   }, (payload) => {                                      │ │
│ │     setProgress(payload.new.processed_rows)             │ │
│ │   })                                                     │ │
│ │                                                           │ │
│ │ UI shows:                                                │ │
│ │ ┌────────────────────────────────────────────────────┐  │ │
│ │ │ Processing leads...                                 │  │ │
│ │ │ [████████████████░░░░░░░░] 3,200 / 5,000          │  │ │
│ │ │ Success: 3,150  Failed: 50                         │  │ │
│ │ └────────────────────────────────────────────────────┘  │ │
│ └──────────────────────────────────────────────────────────┘ │
└──────────────────┬───────────────────────────────────────────┘
                   ▼
┌──────────────────────────────────────────────────────────────┐
│ STEP 8: COMPLETION                                            │
│ ┌──────────────────────────────────────────────────────────┐ │
│ │ ✅ Import Complete!                                      │ │
│ │                                                           │ │
│ │ Successfully Imported: 4,950                             │ │
│ │ Failed: 50                                               │ │
│ │                                                           │ │
│ │ Errors:                                                  │ │
│ │ • Row 234: Missing required field 'phone'               │ │
│ │ • Row 567: Invalid email format                         │ │
│ │ • Row 890: Duplicate phone number                       │ │
│ │ ... (showing first 10 errors)                           │ │
│ │                                                           │ │
│ │ [Import Another File]                                    │ │
│ └──────────────────────────────────────────────────────────┘ │
└──────────────────────────────────────────────────────────────┘
```


---

## 8. Authentication Flow

```
┌─────────────────────────────────────────────────────────────────┐
│ SCENARIO: User logs in and accesses the system                  │
└─────────────────────────────────────────────────────────────────┘

STEP 1: LOGIN
┌──────────────────────────────────────────────────────────────┐
│ Login Page                                                    │
│ ┌──────────────────────────────────────────────────────────┐ │
│ │ Email: admin@example.com                                 │ │
│ │ Password: ••••••••                                       │ │
│ │ [Login]                                                   │ │
│ └──────────────────────────────────────────────────────────┘ │
└──────────────────┬───────────────────────────────────────────┘
                   ▼
┌──────────────────────────────────────────────────────────────┐
│ lib/auth.ts → signIn()                                        │
│ ┌──────────────────────────────────────────────────────────┐ │
│ │ const { data, error } = await supabase.auth             │ │
│ │   .signInWithPassword({ email, password })              │ │
│ │                                                           │ │
│ │ // Get user role from database                           │ │
│ │ const role = await getUserRole(data.user.id)            │ │
│ └──────────────────────────────────────────────────────────┘ │
└──────────────────┬───────────────────────────────────────────┘
                   ▼
┌──────────────────────────────────────────────────────────────┐
│ STEP 2: GET USER ROLE (with caching)                         │
│ ┌──────────────────────────────────────────────────────────┐ │
│ │ // Check cache first (1 min TTL)                         │ │
│ │ const cached = roleCache.get(userId)                     │ │
│ │ if (cached && !expired) return cached.role               │ │
│ │                                                           │ │
│ │ // Query database                                        │ │
│ │ SELECT role FROM users WHERE id = userId                 │ │
│ │                                                           │ │
│ │ // Cache result                                          │ │
│ │ roleCache.set(userId, { role, timestamp })              │ │
│ └──────────────────────────────────────────────────────────┘ │
└──────────────────┬───────────────────────────────────────────┘
                   ▼
┌──────────────────────────────────────────────────────────────┐
│ STEP 3: AUTH CONTEXT UPDATES                                  │
│ contexts/AuthContext.tsx                                      │
│ ┌──────────────────────────────────────────────────────────┐ │
│ │ const [user, setUser] = useState<AuthUser | null>(null) │ │
│ │                                                           │ │
│ │ // On login success                                      │ │
│ │ setUser({                                                │ │
│ │   id: 'user-uuid',                                       │ │
│ │   email: 'admin@example.com',                           │ │
│ │   role: 'admin'                                          │ │
│ │ })                                                        │ │
│ │                                                           │ │
│ │ // Store session in localStorage                         │ │
│ │ // Supabase handles token refresh automatically          │ │
│ └──────────────────────────────────────────────────────────┘ │
└──────────────────┬───────────────────────────────────────────┘
                   ▼
┌──────────────────────────────────────────────────────────────┐
│ STEP 4: REDIRECT TO HOME                                      │
│ router.push('/')                                              │
└──────────────────┬───────────────────────────────────────────┘
                   ▼
┌──────────────────────────────────────────────────────────────┐
│ STEP 5: PAGE CHECKS AUTH                                      │
│ app/page.tsx                                                  │
│ ┌──────────────────────────────────────────────────────────┐ │
│ │ const { user, loading } = useAuth()                      │ │
│ │                                                           │ │
│ │ useEffect(() => {                                        │ │
│ │   if (!loading && !user) {                              │ │
│ │     router.push('/login')  // Not authenticated         │ │
│ │   }                                                       │ │
│ │ }, [user, loading])                                      │ │
│ │                                                           │ │
│ │ if (loading) return <Spinner />                          │ │
│ │ if (!user) return null                                   │ │
│ │                                                           │ │
│ │ // User is authenticated, render page                    │ │
│ │ return <LeadsPage />                                     │ │
│ └──────────────────────────────────────────────────────────┘ │
└──────────────────┬───────────────────────────────────────────┘
                   ▼
┌──────────────────────────────────────────────────────────────┐
│ STEP 6: RLS POLICIES ENFORCE ACCESS                           │
│ ┌──────────────────────────────────────────────────────────┐ │
│ │ Every database query checks:                             │ │
│ │                                                           │ │
│ │ SELECT * FROM leads                                      │ │
│ │ WHERE                                                     │ │
│ │   -- RLS Policy automatically added:                     │ │
│ │   (                                                       │ │
│ │     is_admin_or_manager()  ← Calls helper function     │ │
│ │     OR assigned_to = auth.uid()                         │ │
│ │   )                                                       │ │
│ │                                                           │ │
│ │ Role-Based Access:                                       │ │
│ │ • Admin: Sees ALL leads                                  │ │
│ │ • Manager: Sees ALL leads                                │ │
│ │ • Sales Rep: Sees ONLY assigned leads                    │ │
│ │ • Viewer: Sees ONLY assigned leads                       │ │
│ └──────────────────────────────────────────────────────────┘ │
└──────────────────────────────────────────────────────────────┘

TOKEN REFRESH (Automatic)
┌──────────────────────────────────────────────────────────────┐
│ Supabase Client (lib/supabase.ts)                            │
│ ┌──────────────────────────────────────────────────────────┐ │
│ │ createClient(url, key, {                                 │ │
│ │   auth: {                                                │ │
│ │     autoRefreshToken: true,  ← Enabled                  │ │
│ │     persistSession: true                                 │ │
│ │   }                                                       │ │
│ │ })                                                        │ │
│ │                                                           │ │
│ │ Token expires after 1 hour                               │ │
│ │ Supabase automatically refreshes before expiry           │ │
│ │ AuthContext listens for TOKEN_REFRESHED event            │ │
│ │ No user action required                                  │ │
│ └──────────────────────────────────────────────────────────┘ │
└──────────────────────────────────────────────────────────────┘
```


---

## 9. Realtime Updates Flow

```
┌─────────────────────────────────────────────────────────────────┐
│ SCENARIO: Admin assigns a lead, Sales Rep sees it instantly     │
└─────────────────────────────────────────────────────────────────┘

SETUP: REALTIME SUBSCRIPTION
┌──────────────────────────────────────────────────────────────┐
│ hooks/useRealtime.ts                                          │
│ ┌──────────────────────────────────────────────────────────┐ │
│ │ export function useRealtime({ table, queryKey }) {       │ │
│ │   const queryClient = useQueryClient()                   │ │
│ │                                                           │ │
│ │   useEffect(() => {                                      │ │
│ │     const channel = supabase                            │ │
│ │       .channel(`realtime-${table}`)                     │ │
│ │       .on('postgres_changes', {                         │ │
│ │         event: '*',  // INSERT, UPDATE, DELETE          │ │
│ │         schema: 'public',                               │ │
│ │         table: table                                    │ │
│ │       }, (payload) => {                                  │ │
│ │         console.log('Realtime update:', payload)        │ │
│ │         queryClient.invalidateQueries(queryKey)         │ │
│ │       })                                                 │ │
│ │       .subscribe()                                       │ │
│ │                                                           │ │
│ │     return () => channel.unsubscribe()                  │ │
│ │   }, [])                                                 │ │
│ │ }                                                         │ │
│ └──────────────────────────────────────────────────────────┘ │
└──────────────────────────────────────────────────────────────┘

EVENT FLOW:
┌──────────────────────────────────────────────────────────────┐
│ 1. ADMIN ASSIGNS LEAD                                         │
│    UPDATE leads                                               │
│    SET assigned_to = 'sales-rep-uuid'                        │
│    WHERE id = 'lead-123'                                     │
└──────────────────┬───────────────────────────────────────────┘
                   │
                   ▼
┌──────────────────────────────────────────────────────────────┐
│ 2. POSTGRESQL TRIGGERS NOTIFICATION                           │
│    • Table has REPLICA IDENTITY FULL                          │
│    • Change is added to replication slot                      │
│    • Supabase Realtime server picks up change                │
└──────────────────┬───────────────────────────────────────────┘
                   │
                   ▼
┌──────────────────────────────────────────────────────────────┐
│ 3. SUPABASE BROADCASTS TO SUBSCRIBERS                         │
│    WebSocket message sent to all connected clients:           │
│    {                                                          │
│      event: 'UPDATE',                                         │
│      table: 'leads',                                          │
│      old: { assigned_to: null, ... },                        │
│      new: { assigned_to: 'sales-rep-uuid', ... }            │
│    }                                                          │
└──────────────────┬───────────────────────────────────────────┘
                   │
                   ▼
┌──────────────────────────────────────────────────────────────┐
│ 4. CLIENT RECEIVES UPDATE                                     │
│    useRealtime hook catches the event                         │
│    ├─ Logs: "Realtime update: UPDATE on leads"              │
│    └─ Calls: queryClient.invalidateQueries(['leads'])        │
└──────────────────┬───────────────────────────────────────────┘
                   │
                   ▼
┌──────────────────────────────────────────────────────────────┐
│ 5. REACT QUERY REFETCHES DATA                                 │
│    • Marks cached data as stale                               │
│    • Triggers background refetch                              │
│    • Updates UI when new data arrives                         │
└──────────────────┬───────────────────────────────────────────┘
                   │
                   ▼
┌──────────────────────────────────────────────────────────────┐
│ 6. UI UPDATES AUTOMATICALLY                                   │
│    Sales Rep's screen:                                        │
│    ┌────────────────────────────────────────────────────┐   │
│    │ My Leads (25 → 26)  ← Count updated                │   │
│    │                                                     │   │
│    │ [New lead appears at top of list]                  │   │
│    │ • John Doe                                          │   │
│    │   ABC School | Male | Science                      │   │
│    │   Assigned: Just now                                │   │
│    └────────────────────────────────────────────────────┘   │
└──────────────────────────────────────────────────────────────┘

MULTIPLE SUBSCRIPTIONS:
┌──────────────────────────────────────────────────────────────┐
│ Each hook subscribes independently:                           │
│                                                               │
│ useLeads()           → Subscribes to 'leads' table           │
│ useFilterValueCounts() → Subscribes to 'leads' table         │
│ useUniqueValues()    → Subscribes to 'leads' table           │
│                                                               │
│ When lead changes:                                            │
│ ├─ All three hooks receive notification                       │
│ ├─ All three invalidate their caches                          │
│ └─ All three refetch their data                               │
│                                                               │
│ Result: Entire UI stays in sync automatically                │
└──────────────────────────────────────────────────────────────┘

PERFORMANCE OPTIMIZATION:
┌──────────────────────────────────────────────────────────────┐
│ • Debounced refetches (prevent rapid updates)                │
│ • Stale-while-revalidate (show old data while fetching)      │
│ • Background refetch (no loading spinners)                    │
│ • Automatic retry on failure                                  │
│ • Connection recovery on disconnect                           │
└──────────────────────────────────────────────────────────────┘
```


---

## 10. Complete Interaction Map

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         COMPLETE SYSTEM INTERACTION MAP                      │
└─────────────────────────────────────────────────────────────────────────────┘

FRONTEND LAYER
═══════════════════════════════════════════════════════════════════════════════

┌─────────────────────────────────────────────────────────────────────────────┐
│ PAGES                    COMPONENTS                  HOOKS                   │
│ ─────                    ──────────                  ─────                   │
│                                                                               │
│ app/page.tsx            FilterPanel.tsx             useLeads()              │
│   │                       │                           │                      │
│   ├─ Renders table       ├─ School filter           ├─ Fetches leads       │
│   ├─ Pagination          ├─ District filter         ├─ Watches filters     │
│   └─ Bulk actions        ├─ Gender filter           └─ Caches results      │
│                          ├─ Stream filter                                    │
│ app/manage-buckets      ├─ Search box              useFilterValueCounts()  │
│   │                      └─ Date range               │                      │
│   ├─ Bucket CRUD                                     ├─ Gets counts         │
│   └─ Custom fields      LeadTable.tsx               ├─ Faceted search      │
│                          │                           └─ Shows badges        │
│ app/manage-users        ├─ Displays leads                                   │
│   │                      ├─ Sorting                 useUniqueValues()       │
│   └─ User management    └─ Selection                │                      │
│                                                       ├─ Dropdown options    │
│ app/login               BulkAssignDialog.tsx        └─ All schools/etc     │
│   │                      │                                                   │
│   └─ Authentication     ├─ User selection          useBulkAssign()         │
│                          ├─ Distribution            │                      │
│                          └─ Progress                ├─ Edge function       │
│                                                      └─ Batch updates       │
│                         CSVUpload.tsx                                        │
│                          │                          useBulkDelete()         │
│                          ├─ File upload             │                      │
│                          ├─ Column mapping          ├─ Edge function       │
│                          └─ Progress                └─ Batch deletes       │
│                                                                               │
└─────────────────────────────────────────────────────────────────────────────┘
                                        │
                                        ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│ STATE MANAGEMENT (Zustand)                                                   │
│ ──────────────────────────                                                   │
│                                                                               │
│ filterStore.ts                                                               │
│ ├─ Immediate state (UI)          ← User types/selects                       │
│ │  • school: ['ABC']                                                         │
│ │  • gender: ['Male']                                                        │
│ │  • searchQuery: 'John'                                                     │
│ │                                                                             │
│ ├─ Debounced state (API)         ← After 800ms delay                        │
│ │  • debouncedSchool: ['ABC']                                                │
│ │  • debouncedGender: ['Male']                                               │
│ │  • debouncedSearchQuery: 'John'                                            │
│ │                                                                             │
│ └─ Pagination                                                                │
│    • page: 0                                                                 │
│    • pageSize: 100                                                           │
│    • paginationMode: 'standard'                                              │
│                                                                               │
└─────────────────────────────────────────────────────────────────────────────┘
                                        │
                                        ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│ CACHING LAYER (React Query)                                                  │
│ ───────────────────────────────                                              │
│                                                                               │
│ Query Keys:                          Cache Duration:                         │
│ ├─ ['leads', {...filters}]          30 seconds                              │
│ ├─ ['filter-counts', {...filters}]  30 seconds                              │
│ ├─ ['unique-values']                 60 seconds                              │
│ └─ ['import-job', jobId]             Realtime updates                        │
│                                                                               │
│ Features:                                                                     │
│ ├─ Automatic refetch on stale                                                │
│ ├─ Background updates                                                        │
│ ├─ Retry on failure                                                          │
│ ├─ Optimistic updates                                                        │
│ └─ Realtime invalidation                                                     │
│                                                                               │
└─────────────────────────────────────────────────────────────────────────────┘
                                        │
                                        ▼

API LAYER
═══════════════════════════════════════════════════════════════════════════════

┌─────────────────────────────────────────────────────────────────────────────┐
│ NEXT.JS API ROUTES                   EDGE FUNCTIONS                          │
│ ──────────────────                   ──────────────                          │
│                                                                               │
│ /api/leads                           bulk-assign-leads                       │
│ ├─ POST: Get filtered leads          ├─ Authenticate                         │
│ ├─ Applies filters                   ├─ Build query                          │
│ ├─ Pagination                        ├─ Fetch IDs                            │
│ └─ Joins with users                  ├─ Distribute                           │
│                                       └─ Batch update                         │
│ /api/filter-counts                                                            │
│ ├─ POST: Get faceted counts          bulk-delete-leads                       │
│ ├─ Calls DB function                 ├─ Authenticate                         │
│ └─ Returns JSONB                     ├─ Build query                          │
│                                       ├─ Fetch IDs                            │
│ /api/unique-values                   └─ Batch delete                         │
│ ├─ GET: Get all options                                                      │
│ ├─ Calls DB function                 import-csv-leads                        │
│ └─ Server-side aggregation           ├─ Download CSV                         │
│                                       ├─ Parse rows                           │
│ /api/admin/update-password           ├─ Transform data                       │
│ └─ POST: Admin password reset        ├─ Batch insert                         │
│                                       ├─ Track progress                       │
│                                       └─ Handle errors                        │
│                                                                               │
└─────────────────────────────────────────────────────────────────────────────┘
                                        │
                                        ▼

DATABASE LAYER
═══════════════════════════════════════════════════════════════════════════════

┌─────────────────────────────────────────────────────────────────────────────┐
│ POSTGRESQL TABLES                    FUNCTIONS                               │
│ ─────────────────                    ─────────                               │
│                                                                               │
│ users                                is_admin()                              │
│ ├─ id (UUID, PK)                     └─ Returns: boolean                     │
│ ├─ email (TEXT)                      └─ Used in: RLS policies               │
│ ├─ role (TEXT)                                                               │
│ ├─ name (TEXT)                       is_admin_or_manager()                   │
│ └─ Indexes: role                     └─ Returns: boolean                     │
│                                       └─ Used in: RLS policies               │
│ leads                                                                         │
│ ├─ id (UUID, PK)                     current_user_role()                     │
│ ├─ name (TEXT)                       └─ Returns: TEXT                        │
│ ├─ phone (TEXT)                      └─ Used in: Application logic          │
│ ├─ school (TEXT)                                                             │
│ ├─ district (TEXT)                   get_filter_counts(...)                  │
│ ├─ gender (TEXT)                     ├─ Parameters: 8 filters                │
│ ├─ stream (TEXT)                     ├─ Returns: JSONB                       │
│ ├─ custom_fields (JSONB)             ├─ Logic: Faceted search               │
│ ├─ assigned_to (UUID, FK)            └─ Performance: ~200-800ms             │
│ ├─ created_by (UUID, FK)                                                     │
│ └─ Indexes: 11 indexes               get_unique_values()                     │
│    • school, district, etc.          ├─ Returns: JSONB                       │
│    • GIN on custom_fields            ├─ Logic: DISTINCT aggregation         │
│    • pg_trgm on name, phone          └─ Performance: ~100-400ms             │
│                                                                               │
│ lead_buckets                         get_custom_field_unique_values(...)     │
│ ├─ id (UUID, PK)                     ├─ Parameter: field_name                │
│ ├─ name (TEXT, UNIQUE)               ├─ Returns: TABLE(value TEXT)          │
│ ├─ description (TEXT)                └─ Logic: DISTINCT on JSONB field      │
│ ├─ is_active (BOOLEAN)                                                       │
│ └─ color (TEXT)                      handle_new_user()                       │
│                                       ├─ Trigger: ON INSERT auth.users       │
│ custom_fields                        └─ Logic: Auto-create profile          │
│ ├─ id (UUID, PK)                                                             │
│ ├─ bucket_id (UUID, FK)              update_updated_at_column()              │
│ ├─ name (TEXT)                       ├─ Trigger: ON UPDATE (all tables)     │
│ ├─ label (TEXT)                      └─ Logic: Set updated_at = NOW()       │
│ ├─ field_type (TEXT)                                                         │
│ └─ options (JSONB)                                                           │
│                                                                               │
│ import_jobs                                                                   │
│ ├─ id (UUID, PK)                                                             │
│ ├─ user_id (UUID, FK)                                                        │
│ ├─ status (TEXT)                                                             │
│ ├─ total_rows (INTEGER)                                                      │
│ ├─ success_count (INTEGER)                                                   │
│ ├─ failed_count (INTEGER)                                                    │
│ └─ errors (JSONB)                                                            │
│                                                                               │
└─────────────────────────────────────────────────────────────────────────────┘
                                        │
                                        ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│ RLS POLICIES (Row Level Security)                                            │
│ ──────────────────────────────────                                           │
│                                                                               │
│ leads table:                                                                  │
│ ├─ SELECT: is_admin_or_manager() OR assigned_to = auth.uid()                │
│ ├─ INSERT: is_admin_or_manager()                                             │
│ ├─ UPDATE: is_admin_or_manager() OR assigned_to = auth.uid()                │
│ └─ DELETE: is_admin_or_manager()                                             │
│                                                                               │
│ users table:                                                                  │
│ ├─ SELECT: auth.uid() = id OR authenticated                                  │
│ ├─ UPDATE: auth.uid() = id                                                   │
│ └─ INSERT: is_admin()                                                        │
│                                                                               │
│ lead_buckets table:                                                           │
│ ├─ SELECT: is_active = true                                                  │
│ └─ ALL: is_admin()                                                           │
│                                                                               │
│ custom_fields table:                                                          │
│ ├─ SELECT: bucket is_active = true                                           │
│ └─ ALL: is_admin()                                                           │
│                                                                               │
│ import_jobs table:                                                            │
│ ├─ SELECT: user_id = auth.uid() OR is_admin()                               │
│ └─ INSERT: user_id = auth.uid()                                              │
│                                                                               │
└─────────────────────────────────────────────────────────────────────────────┘
                                        │
                                        ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│ STORAGE                              REALTIME                                 │
│ ───────                              ────────                                 │
│                                                                               │
│ csv-imports bucket                   Subscriptions:                           │
│ ├─ Structure:                        ├─ leads table                          │
│ │  user-uuid/                        ├─ import_jobs table                    │
│ │  └─ timestamp_file.csv             └─ Broadcasts: INSERT, UPDATE, DELETE  │
│ │                                                                             │
│ ├─ RLS Policies:                     Features:                               │
│ │  • INSERT: own folder              ├─ WebSocket connection                 │
│ │  • SELECT: own folder              ├─ Automatic reconnect                  │
│ │  • DELETE: own folder              ├─ Change data capture                  │
│ │                                     └─ Filtered subscriptions              │
│ └─ Auto-cleanup after import                                                 │
│                                                                               │
└─────────────────────────────────────────────────────────────────────────────┘
```


---

## Summary: Key Architectural Decisions

### 1. **Debounced Filters (800ms)**
- **Why**: Prevents excessive API calls while user types
- **How**: Zustand store maintains both immediate and debounced state
- **Result**: 4 API calls → 1 API call when typing "John"

### 2. **Server-Side Functions**
- **Why**: Bypass 1000-row limit, respect RLS, better performance
- **Functions**: `get_filter_counts()`, `get_unique_values()`, `get_custom_field_unique_values()`
- **Result**: Can aggregate millions of rows efficiently

### 3. **Optimized RLS Policies**
- **Why**: Inline subqueries were slow (1-2s per query)
- **How**: Helper functions `is_admin()`, `is_admin_or_manager()` with caching
- **Result**: 10-100x faster queries (~50-200ms)

### 4. **React Query Caching**
- **Why**: Reduce database load, improve UX
- **Strategy**: 30-60s cache + realtime invalidation
- **Result**: Instant UI updates, fewer database queries

### 5. **Faceted Search**
- **Why**: Show users what filters are available
- **How**: Count each field while excluding that field from filters
- **Result**: "Male (1,200)" "Female (1,300)" badges

### 6. **Edge Functions for Bulk Operations**
- **Why**: Client-side limited by browser, network, RLS
- **How**: Server-side processing with batching
- **Result**: Can process 10,000+ leads efficiently

### 7. **Realtime Updates**
- **Why**: Keep all users in sync
- **How**: PostgreSQL replication + WebSocket broadcasts
- **Result**: Instant updates across all connected clients

### 8. **Role-Based Access Control**
- **Why**: Security and data isolation
- **How**: RLS policies + helper functions
- **Result**: Admin sees all, Sales Rep sees only assigned

### 9. **CSV Import with Progress**
- **Why**: Handle large imports without blocking
- **How**: Edge function + realtime progress updates
- **Result**: Import 5,000 leads with live progress bar

### 10. **Performance Indexes**
- **Why**: Fast queries on large datasets
- **Indexes**: 11 indexes on leads table + pg_trgm for text search
- **Result**: Sub-second queries on millions of rows

---

## Performance Metrics

| Operation | Before Optimization | After Optimization |
|-----------|--------------------|--------------------|
| Page Load | 1.6s - 2s | <500ms |
| Filter Change | 1.2s - 1.5s | <200ms |
| Bulk Assign (1000) | 30s - 60s | 5s - 10s |
| CSV Import (5000) | N/A | 30s - 60s |
| Filter Counts | 2s - 5s | 200ms - 800ms |
| Unique Values | 1s - 2s | 100ms - 400ms |

---

## Data Flow Summary

```
USER ACTION
    ↓
COMPONENT (React)
    ↓
HOOK (React Query)
    ↓
STORE (Zustand) ← Debounce 800ms
    ↓
API ROUTE (Next.js) OR EDGE FUNCTION
    ↓
DATABASE FUNCTION (PostgreSQL)
    ↓
RLS POLICY CHECK (Security)
    ↓
INDEXES (Performance)
    ↓
RESULT
    ↓
CACHE (React Query)
    ↓
COMPONENT RE-RENDER
    ↓
USER SEES UPDATE

REALTIME (Parallel):
DATABASE CHANGE → REPLICATION → WEBSOCKET → INVALIDATE CACHE → REFETCH → UPDATE UI
```

---

## File Structure Reference

```
Lead Management System
├── Frontend
│   ├── app/
│   │   ├── page.tsx (Main leads page)
│   │   ├── manage-buckets/page.tsx
│   │   ├── manage-users/page.tsx
│   │   ├── login/page.tsx
│   │   └── api/
│   │       ├── leads/route.ts
│   │       ├── filter-counts/route.ts
│   │       └── unique-values/route.ts
│   ├── components/
│   │   ├── filters/FilterPanel.tsx
│   │   ├── leads/LeadTable.tsx
│   │   ├── leads/BulkAssignDialog.tsx
│   │   └── csv-upload/CSVUpload.tsx
│   ├── hooks/
│   │   ├── useLeads.ts
│   │   ├── useFilterValueCounts.ts
│   │   ├── useUniqueValues.ts
│   │   ├── useBulkAssign.ts
│   │   ├── useBulkDelete.ts
│   │   └── useRealtime.ts
│   ├── stores/
│   │   └── filterStore.ts (Zustand)
│   ├── contexts/
│   │   └── AuthContext.tsx
│   └── lib/
│       ├── supabase.ts
│       └── auth.ts
├── Backend (Supabase)
│   ├── migrations/
│   │   └── 00000000000000_complete_optimized_schema.sql
│   └── functions/
│       ├── bulk-assign-leads/
│       ├── bulk-delete-leads/
│       └── import-csv-leads/
└── Database
    ├── Tables: users, leads, lead_buckets, custom_fields, import_jobs
    ├── Functions: get_filter_counts, get_unique_values, is_admin, etc.
    ├── RLS Policies: Role-based access control
    └── Indexes: 11 performance indexes
```

---

**End of Architecture Documentation**

This document provides a complete visual representation of how every component, hook, store, function, and database element works together in the Lead Management System.

