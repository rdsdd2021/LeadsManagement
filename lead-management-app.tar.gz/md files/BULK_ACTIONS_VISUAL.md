# Bulk Actions System - Visual Guide

## 🎨 User Interface Overview

### Main Screen Layout

```
┌─────────────────────────────────────────────────────────────────────┐
│  Leads (246)  [50 selected]                                         │
│                                                                      │
│  [∞ Infinite Scroll] [Select Leads] [Bulk Actions (50) ▼]          │
├─────────────────────────────────────────────────────────────────────┤
│  Showing 1 to 100 of 246 results    Per page: [100 ▼]              │
│  [⏮] [◀] [1] [2] [3] [▶] [⏭]                                      │
├─────────────────────────────────────────────────────────────────────┤
│  [✓] │ Name         │ Status    │ Category      │ Value │ Assigned │
│  [✓] │ John Doe     │ new       │ Real Estate   │ $5000 │ Unassigned│
│  [ ] │ Jane Smith   │ qualified │ IT Services   │ $3000 │ Unassigned│
│  [✓] │ Bob Johnson  │ new       │ Healthcare    │ $7000 │ Unassigned│
│  ...                                                                 │
└─────────────────────────────────────────────────────────────────────┘
```

## 📋 Bulk Select Dialog

### Opening the Dialog

**Click:** "Select Leads" button

```
┌──────────────────────────────────────────────────────┐
│  Select Leads for Bulk Action                    [×] │
├──────────────────────────────────────────────────────┤
│  Choose how many leads to select from your           │
│  filtered results                                     │
│                                                       │
│  ┌────────────────────────────────────────────────┐ │
│  │ ℹ️ Current Status:                              │ │
│  │ • Total filtered leads: 140                    │ │
│  │ • Currently selected: 10                       │ │
│  └────────────────────────────────────────────────┘ │
│                                                       │
│  Number of Leads to Select                           │
│  ┌──────────────────────────────────────┐           │
│  │ 50                                   │           │
│  └──────────────────────────────────────┘           │
│  Maximum: 140 leads                                  │
│                                                       │
│  Quick Select:                                       │
│  ┌────┐ ┌────┐ ┌─────┐ ┌─────┐                     │
│  │ 10 │ │ 50 │ │ 100 │ │ All │                     │
│  └────┘ └────┘ └─────┘ └─────┘                     │
│                                                       │
│  ┌────────────────────────────────────────────────┐ │
│  │ ✓ Selection Preview:                           │ │
│  │ 50 leads will be selected from your            │ │
│  │ filtered results (newest first)                │ │
│  └────────────────────────────────────────────────┘ │
│                                                       │
│  • Leads are selected in order (newest first)        │
│  • Selection respects your current filters           │
│  • You can perform bulk actions after selection      │
│                                                       │
│                        ┌────────┐ ┌──────────────┐  │
│                        │ Cancel │ │ Select 50... │  │
│                        └────────┘ └──────────────┘  │
└──────────────────────────────────────────────────────┘
```

## 🎯 Bulk Actions Menu

### Dropdown Menu

**Click:** "Bulk Actions (50)" button

```
┌─────────────────────────────────┐
│ Bulk Actions (50) ▼             │
└─────────────────────────────────┘
              │
              ▼
┌───────────────────────────────────────┐
│ Actions for 50 leads                  │
├───────────────────────────────────────┤
│ 👤 Assign to Users                    │
│ 📥 Export Selected                    │
│ ✉️  Send Email                        │
│ 🏷️  Add Tags                          │
│ 📦 Archive                            │
├───────────────────────────────────────┤
│ 🗑️  Delete Selected                   │
└───────────────────────────────────────┘
```

### Menu States

**No Selection (Disabled):**
```
┌─────────────────────────────────┐
│ Bulk Actions (0) ▼  [DISABLED]  │
└─────────────────────────────────┘
```

**With Selection (Active):**
```
┌─────────────────────────────────┐
│ Bulk Actions (50) ▼  [ACTIVE]   │
└─────────────────────────────────┘
```

**During Action (Loading):**
```
┌─────────────────────────────────┐
│ ⟳ Bulk Actions (50) [LOADING]   │
└─────────────────────────────────┘
```

## 🔄 User Workflows

### Workflow 1: Quick Bulk Select

```
Step 1: Apply Filters
┌─────────────────────────────────┐
│ Status: [new] [qualified]       │
│ Category: [Real Estate]         │
│ → Filtered: 140 leads           │
└─────────────────────────────────┘
              ↓
Step 2: Click "Select Leads"
┌─────────────────────────────────┐
│ [Select Leads] ← Click          │
└─────────────────────────────────┘
              ↓
Step 3: Choose Count
┌─────────────────────────────────┐
│ Quick Select:                   │
│ [10] [50] [100] [All]          │
│      ↑ Click                    │
└─────────────────────────────────┘
              ↓
Step 4: Confirm
┌─────────────────────────────────┐
│ [Select 50 Leads] ← Click       │
└─────────────────────────────────┘
              ↓
Step 5: Choose Action
┌─────────────────────────────────┐
│ Bulk Actions (50) ▼ ← Click     │
│   ├─ Assign to Users ← Click    │
│   ├─ Delete Selected            │
│   └─ ...                        │
└─────────────────────────────────┘
              ↓
Step 6: Complete Action
┌─────────────────────────────────┐
│ ✓ Action completed!             │
│ Selection cleared               │
└─────────────────────────────────┘
```

### Workflow 2: Manual + Bulk Select

```
Step 1: Manual Selection
┌─────────────────────────────────┐
│ [✓] Lead 1                      │
│ [✓] Lead 2                      │
│ [✓] Lead 3                      │
│ → 3 selected                    │
└─────────────────────────────────┘
              ↓
Step 2: Increase Selection
┌─────────────────────────────────┐
│ [Select Leads] ← Click          │
│ Current: 3 selected             │
│ Change to: 50                   │
└─────────────────────────────────┘
              ↓
Step 3: Perform Action
┌─────────────────────────────────┐
│ Bulk Actions (50) ▼             │
│ → Choose action                 │
└─────────────────────────────────┘
```

### Workflow 3: Manual Only

```
Step 1: Select with Checkboxes
┌─────────────────────────────────┐
│ [✓] Lead 1                      │
│ [✓] Lead 2                      │
│ [ ] Lead 3                      │
│ [✓] Lead 4                      │
│ → 3 selected                    │
└─────────────────────────────────┘
              ↓
Step 2: Direct Action
┌─────────────────────────────────┐
│ Bulk Actions (3) ▼ ← Click      │
│ → Choose action                 │
└─────────────────────────────────┘
```

## 🎨 Visual States

### Selection Counter

**No Selection:**
```
Leads (246)
```

**With Selection:**
```
Leads (246)  [50 selected]
             ↑ Blue, bold
```

**During Action:**
```
Leads (246)  [50 selected] ⟳
                           ↑ Loading spinner
```

### Button States

**Select Leads Button:**
```
Normal:   [Select Leads]
Hover:    [Select Leads] ← Highlighted
Disabled: [Select Leads] ← Grayed out
```

**Bulk Actions Button:**
```
Disabled:  [Bulk Actions (0) ▼] ← Grayed
Active:    [Bulk Actions (50) ▼] ← Blue
Loading:   [⟳ Bulk Actions (50)] ← Spinner
```

## 🎯 Action Confirmations

### Delete Confirmation

```
┌──────────────────────────────────────────┐
│  ⚠️  Confirm Deletion                     │
├──────────────────────────────────────────┤
│  Are you sure you want to delete         │
│  50 lead(s)?                             │
│                                          │
│  This action cannot be undone.           │
│                                          │
│           ┌────────┐ ┌──────────┐       │
│           │ Cancel │ │ Delete   │       │
│           └────────┘ └──────────┘       │
└──────────────────────────────────────────┘
```

### Success Message

```
┌──────────────────────────────────────────┐
│  ✓ Success!                              │
├──────────────────────────────────────────┤
│  Successfully deleted 50 lead(s)         │
│                                          │
│                        ┌────────┐        │
│                        │   OK   │        │
│                        └────────┘        │
└──────────────────────────────────────────┘
```

### Error Message

```
┌──────────────────────────────────────────┐
│  ❌ Error                                 │
├──────────────────────────────────────────┤
│  Failed to delete leads:                 │
│  Permission denied                       │
│                                          │
│                        ┌────────┐        │
│                        │   OK   │        │
│                        └────────┘        │
└──────────────────────────────────────────┘
```

## 📱 Responsive Design

### Desktop (Wide)
```
[Select Leads] [Bulk Actions (50) ▼]
```

### Tablet (Medium)
```
[Select] [Actions (50) ▼]
```

### Mobile (Narrow)
```
[Select]
[Actions ▼]
```

## 🎨 Color Scheme

### Selection Counter
- **Color:** Blue (#3B82F6)
- **Font:** Bold
- **Background:** None

### Buttons
- **Primary:** Blue (#3B82F6)
- **Outline:** Gray border
- **Hover:** Light blue background
- **Disabled:** Gray (#9CA3AF)

### Menu Items
- **Normal:** Black text
- **Hover:** Light gray background
- **Destructive:** Red text (#DC2626)
- **Destructive Hover:** Light red background

### Dialogs
- **Info Box:** Blue background (#EFF6FF)
- **Success Box:** Green background (#F0FDF4)
- **Error Box:** Red background (#FEF2F2)

## 🔔 Notifications

### Toast Notifications (Future)

```
┌────────────────────────────────┐
│ ✓ 50 leads assigned            │
└────────────────────────────────┘
  ↑ Appears top-right, auto-dismiss
```

```
┌────────────────────────────────┐
│ ⟳ Deleting 50 leads...         │
└────────────────────────────────┘
  ↑ Progress indicator
```

```
┌────────────────────────────────┐
│ ❌ Action failed               │
│ Click to retry                 │
└────────────────────────────────┘
  ↑ Error with action
```

## 🎯 Keyboard Shortcuts (Future)

```
Ctrl/Cmd + A  → Select All
Ctrl/Cmd + D  → Deselect All
Delete        → Delete Selected
Ctrl/Cmd + E  → Export Selected
Esc           → Close Dialog/Menu
```

## 📊 Progress Indicators

### Bulk Operation Progress (Future)

```
┌──────────────────────────────────────────┐
│  Processing 50 leads...                  │
├──────────────────────────────────────────┤
│  ████████████░░░░░░░░░░░░░░░░░░  40%    │
│                                          │
│  Assigned: 20 / 50                       │
│  Remaining: 30                           │
│                                          │
│                        ┌────────┐        │
│                        │ Cancel │        │
│                        └────────┘        │
└──────────────────────────────────────────┘
```

## 🎉 Summary

The visual design provides:
- ✅ Clear selection feedback
- ✅ Intuitive button placement
- ✅ Accessible color scheme
- ✅ Responsive layout
- ✅ Loading states
- ✅ Error handling
- ✅ Confirmation dialogs
- ✅ Professional appearance

All designed for optimal user experience!
