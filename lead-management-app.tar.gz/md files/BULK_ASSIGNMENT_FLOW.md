# Bulk Assignment Flow Diagram

## User Interface Flow

```
┌─────────────────────────────────────────────────────────────┐
│                      LEADS PAGE (Admin View)                 │
├─────────────────────────────────────────────────────────────┤
│                                                               │
│  Filters Applied: Status=New, Category=Real Estate           │
│  Results: 3400 leads                                          │
│                                                               │
│  ┌──────────────────────────────────────────────────────┐   │
│  │ [✓] Select All    Leads (3400)    [Bulk Assign (50)]│   │
│  └──────────────────────────────────────────────────────┘   │
│                                                               │
│  ┌──────────────────────────────────────────────────────┐   │
│  │ [✓] │ John Doe    │ New      │ Real Estate │ $5000  │   │
│  │ [✓] │ Jane Smith  │ New      │ Real Estate │ $3000  │   │
│  │ [ ] │ Bob Johnson │ New      │ Real Estate │ $7000  │   │
│  │ ...                                                   │   │
│  └──────────────────────────────────────────────────────┘   │
│                                                               │
│  Pagination: [1] 2 3 ... 34  (100 per page)                 │
└─────────────────────────────────────────────────────────────┘
                            │
                            │ Click "Bulk Assign"
                            ▼
┌─────────────────────────────────────────────────────────────┐
│              BULK ASSIGN DIALOG - STEP 1                     │
├─────────────────────────────────────────────────────────────┤
│                                                               │
│  Select Leads to Assign                                       │
│  3400 leads match your current filters                        │
│                                                               │
│  Number of Leads to Assign:                                   │
│  ┌─────────────────────┐                                     │
│  │ 500                 │  Maximum: 3400 leads                │
│  └─────────────────────┘  (50 selected on current page)      │
│                                                               │
│  ┌────────────────────────────────────────────────────┐     │
│  │ ℹ️ How it works:                                    │     │
│  │ • Leads assigned from filtered results              │     │
│  │ • Assignment in order (newest first)                │     │
│  │ • Distribute equally or set custom counts           │     │
│  └────────────────────────────────────────────────────┘     │
│                                                               │
│                    [Cancel]  [Next: Select Users]            │
└─────────────────────────────────────────────────────────────┘
                            │
                            │ Click "Next"
                            ▼
┌─────────────────────────────────────────────────────────────┐
│              BULK ASSIGN DIALOG - STEP 2                     │
├─────────────────────────────────────────────────────────────┤
│                                                               │
│  Distribute Leads to Users                                    │
│  Choose how to distribute 500 leads among users               │
│                                                               │
│  Distribution Mode:                                           │
│  ◉ Equal distribution (automatic)                             │
│  ○ Custom count per user                                      │
│                                                               │
│  Select Users (3 selected):                                   │
│  ┌────────────────────────────────────────────────────┐     │
│  │ [✓] Alice Johnson (alice@company.com)              │     │
│  │ [✓] Bob Smith (bob@company.com)                    │     │
│  │ [✓] Carol White (carol@company.com)                │     │
│  │ [ ] David Brown (david@company.com)                │     │
│  └────────────────────────────────────────────────────┘     │
│                                                               │
│  ┌────────────────────────────────────────────────────┐     │
│  │ 👥 Distribution Preview                             │     │
│  │                                                      │     │
│  │ Alice Johnson ............................ 167 leads│     │
│  │ Bob Smith ................................ 167 leads│     │
│  │ Carol White .............................. 166 leads│     │
│  │ ─────────────────────────────────────────────────  │     │
│  │ Total .................................... 500 / 500│     │
│  └────────────────────────────────────────────────────┘     │
│                                                               │
│              [Back]  [Cancel]  [Assign Leads]                │
└─────────────────────────────────────────────────────────────┘
                            │
                            │ Click "Assign Leads"
                            ▼
┌─────────────────────────────────────────────────────────────┐
│                    ASSIGNMENT PROCESS                         │
├─────────────────────────────────────────────────────────────┤
│                                                               │
│  1. Get 500 filtered lead IDs (newest first)                 │
│     ↓                                                         │
│  2. Slice leads for each user:                               │
│     • Alice: leads[0:167]                                    │
│     • Bob: leads[167:334]                                    │
│     • Carol: leads[334:500]                                  │
│     ↓                                                         │
│  3. Bulk UPDATE in database:                                 │
│     UPDATE leads SET assigned_to = 'alice_id'                │
│     WHERE id IN (lead_ids[0:167])                            │
│     ↓                                                         │
│  4. Refresh leads table                                      │
│     ↓                                                         │
│  5. Show success message                                     │
│                                                               │
└─────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────┐
│                    RESULT - ADMIN VIEW                        │
├─────────────────────────────────────────────────────────────┤
│                                                               │
│  ✅ Leads assigned successfully!                             │
│                                                               │
│  Leads (3400)                                                 │
│  ┌────────────────────────────────────────────────────┐     │
│  │ John Doe    │ New │ Real Estate │ $5000 │ Assigned │     │
│  │ Jane Smith  │ New │ Real Estate │ $3000 │ Assigned │     │
│  │ Bob Johnson │ New │ Real Estate │ $7000 │ Unassigned│    │
│  └────────────────────────────────────────────────────┘     │
│                                                               │
└─────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│                  RESULT - ALICE'S VIEW                        │
├─────────────────────────────────────────────────────────────┤
│                                                               │
│  My Leads (167)  ← Only sees her assigned leads              │
│  ┌────────────────────────────────────────────────────┐     │
│  │ John Doe    │ New │ Real Estate │ $5000 │ Me       │     │
│  │ Jane Smith  │ New │ Real Estate │ $3000 │ Me       │     │
│  │ ...         │ ... │ ...         │ ...   │ Me       │     │
│  └────────────────────────────────────────────────────┘     │
│                                                               │
│  ❌ No "Bulk Assign" button (not admin)                      │
│  ❌ Cannot see Bob's or Carol's leads (RLS)                  │
│                                                               │
└─────────────────────────────────────────────────────────────┘
```

## Custom Distribution Example

```
┌─────────────────────────────────────────────────────────────┐
│         CUSTOM DISTRIBUTION MODE                              │
├─────────────────────────────────────────────────────────────┤
│                                                               │
│  Distribution Mode:                                           │
│  ○ Equal distribution (automatic)                             │
│  ◉ Custom count per user                                      │
│                                                               │
│  Select Users and Specify Counts:                             │
│  ┌────────────────────────────────────────────────────┐     │
│  │ [✓] Alice Johnson          [200] leads             │     │
│  │ [✓] Bob Smith              [150] leads             │     │
│  │ [✓] Carol White            [150] leads             │     │
│  │ [ ] David Brown            [  0] leads             │     │
│  └────────────────────────────────────────────────────┘     │
│                                                               │
│  ┌────────────────────────────────────────────────────┐     │
│  │ 👥 Distribution Preview                             │     │
│  │                                                      │     │
│  │ Alice Johnson ............................ 200 leads│     │
│  │ Bob Smith ................................ 150 leads│     │
│  │ Carol White .............................. 150 leads│     │
│  │ ─────────────────────────────────────────────────  │     │
│  │ Total .................................... 500 / 500│     │
│  └────────────────────────────────────────────────────┘     │
│                                                               │
└─────────────────────────────────────────────────────────────┘
```

## Row-Level Security Flow

```
┌──────────────────────────────────────────────────────────────┐
│                    DATABASE QUERY                             │
└──────────────────────────────────────────────────────────────┘
                            │
                            ▼
                  ┌─────────────────┐
                  │  Is user admin? │
                  └─────────────────┘
                     │            │
                 Yes │            │ No
                     ▼            ▼
        ┌──────────────────┐  ┌──────────────────────────┐
        │  Return ALL      │  │  Return ONLY:            │
        │  leads           │  │  • assigned_to = user_id │
        │                  │  │  • assigned_to IS NULL   │
        └──────────────────┘  └──────────────────────────┘
                     │                    │
                     └────────┬───────────┘
                              ▼
                    ┌──────────────────┐
                    │  Return Results  │
                    └──────────────────┘
```

## Data Flow Architecture

```
┌─────────────┐      ┌──────────────┐      ┌─────────────┐
│   Browser   │◄────►│  React Query │◄────►│  Supabase   │
│   (UI)      │      │  (Cache)     │      │  (Database) │
└─────────────┘      └──────────────┘      └─────────────┘
      │                     │                      │
      │ User Action         │ Invalidate           │ RLS Check
      │ (Bulk Assign)       │ Cache                │ (Policies)
      ▼                     ▼                      ▼
┌─────────────┐      ┌──────────────┐      ┌─────────────┐
│ useBulkAssign│────►│  Bulk UPDATE │────►│  Update Rows│
│   Hook      │      │  Query       │      │  + Audit    │
└─────────────┘      └──────────────┘      └─────────────┘
      │                     │                      │
      │ Success             │ Refetch              │ Return Count
      ▼                     ▼                      ▼
┌─────────────┐      ┌──────────────┐      ┌─────────────┐
│  Show Alert │      │  Refresh UI  │      │  New Data   │
│  Clear Sel. │      │  Update Table│      │  (Filtered) │
└─────────────┘      └──────────────┘      └─────────────┘
```

## State Management

```
┌────────────────────────────────────────────────────────┐
│                  Component State                        │
├────────────────────────────────────────────────────────┤
│                                                          │
│  selectedLeads: Set<string>                             │
│  ├─ Add/Remove on checkbox click                        │
│  ├─ Clear on page change                                │
│  └─ Clear after successful assignment                   │
│                                                          │
│  showBulkAssign: boolean                                │
│  ├─ Open dialog                                         │
│  └─ Close on cancel/success                             │
│                                                          │
└────────────────────────────────────────────────────────┘

┌────────────────────────────────────────────────────────┐
│                   Dialog State                          │
├────────────────────────────────────────────────────────┤
│                                                          │
│  step: 'count' | 'distribution'                         │
│  assignCount: number                                    │
│  distributionMode: 'equal' | 'custom'                   │
│  selectedUsers: string[]                                │
│  customCounts: Record<string, number>                   │
│                                                          │
└────────────────────────────────────────────────────────┘

┌────────────────────────────────────────────────────────┐
│                  Global State (Zustand)                 │
├────────────────────────────────────────────────────────┤
│                                                          │
│  Filters (status, category, region, etc.)               │
│  ├─ Used to query filtered leads                        │
│  └─ Determines which leads to assign                    │
│                                                          │
└────────────────────────────────────────────────────────┘
```
